using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;

public class Arduino : MonoBehaviour
{

    SerialPort sp = new SerialPort("COM3", 9600);
    public string message2;

    // Start is called before the first frame update
    void Start()
    {
        message2 = sp.ReadLine();
        print(message2);
        

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
