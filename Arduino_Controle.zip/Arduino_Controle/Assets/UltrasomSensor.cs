using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;

public class UltrasomSensor : MonoBehaviour
{

    SerialPort sp = new SerialPort("COM3", 9600);
    public float message2, temp;
    private float updatePeriod = 0.0f;
    public GameObject player;

    // Start is called before the first frame update
    void Start()
    {
        sp.Open();
        sp.ReadTimeout = 1;
    }

    // Update is called once per frame
    void Update()
    {
        updatePeriod += Time.deltaTime;
        if(updatePeriod>0.2f)
        {
            message2 = sp.ReadByte();
            print(message2);
            Vector3 temp = player.transform.position;
            temp.x = (155.0f - message2) / 15.0f;
            player.transform.position = temp;
            updatePeriod = 0.0f;
        }
    }

    
}
