using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;

public class Move : MonoBehaviour
{
    SerialPort sp = new SerialPort("COM3", 9600); //porta arduino
    public float message2, temp;
    private float updatePeriod = 0.0f;
    public GameObject player;
    Arduino arduino;


    // Start is called before the first frame update
    void Start()
    {
        sp.Open();
        sp.ReadTimeout = 1;
    }

    // Update is called once per frame
    void Update()
    {
        
        if (sp.IsOpen)
        {
            
            updatePeriod += Time.deltaTime;

            try
            {
                //arduino = sp.Read()
                //arduino.Split()     split para todos os elementos do controle (botao 1, 2, 3, led 1, 2, 3, sensor ultrasom, sensor reflexivo, giroscopio x, y, z)
                


                if (sp.ReadByte() == 1)
                {
                    transform.Translate(Vector3.left * Time.deltaTime * 150);
                }
                if (sp.ReadByte() == 2)
                {
                    transform.Translate(Vector3.right * Time.deltaTime * 150);
                }

                else { }
            }
            catch (System.Exception) { }


            if (sp.ReadByte() == 3)
            {
                
                if (updatePeriod > 0.2f)
                {
                    message2 = sp.ReadByte();
                    print(message2);
                    temp = (155.0f - message2) / 15.0f;
                    updatePeriod = 0.0f;
                }

                transform.Translate(Vector3.up * Time.deltaTime * temp);
            }
            else 
            {
                //transform.Translate(Vector3.up * Time.deltaTime * 10);
            }
        }
    }
}
